const Shogiground = require('shogiground').Shogiground;
var util = require('./util');

module.exports = {
  instance: config = {},
  set: function (opts) {
    const config = {
      fen: opts.shogi.fen,
      lastMove: null,
      selected: null,
      orientation: opts.orientation,
      coordinates: true,
      pieceKey: true,
      turnColor: opts.shogi.player,
      check: opts.shogi.check,
      autoCastle: opts.autoCastle,
      movable: {
        free: false,
        color: opts.shogi.player,
        dests: opts.shogi.dests
      },
      events: {
        move: opts.onMove
      },
      items: opts.items,
      premovable: {
        enabled: true
      },
      drawable: {
        enabled: true,
        eraseOnClick: true
      },
      highlight: {
        lastMove: true,
        dragOver: true
      },
      animation: {
        enabled: false, // prevent piece animation during transition
        duration: 200
      },
      disableContextMenu: true
    };
    ground.set(config);
    if (opts.shapes) cg.setShapes(opts.shapes.slice(0));
    return cg;
  },
  stop: shogiground.stop(),
  color: function (color, dests) {
    cg.set({
      turnColor: color,
      movable: {
        color: color,
        dests: dests
      }
    });
  },
  fen: function (fen, color, dests, lastMove) {
    var config = {
      turnColor: color,
      fen: fen,
      movable: {
        color: color,
        dests: dests
      }
    };
    if (lastMove) config.lastMove = lastMove;
    ground.set(config);
  },
  check: function (shogi) {
    cg.set({
      check: shogi.check
    });
  },
  promote: function (key, role) {
    var pieces = {};
    var piece = cg.data.pieces[key];
    if (piece) {
      pieces[key] = {
        color: piece.color,
        role: role,
        promoted: true
      };
      cg.setPieces(pieces);
    }
  },
  data: function () {
    return cg.data;
  },
  pieces: function () {
    return cg.data.pieces;
  },
  get: function (key) {
    return cg.data.pieces[key];
  },
  showCapture: function (move) {
    requestAnimationFrame(function () {
      var $square = $('#learn-app piece[data-key=' + move.orig + ']');
      $square.addClass('wriggle');
      setTimeout(function () {
        $square.removeClass('wriggle');
        cg.setShapes([]);
        cg.apiMove(move.orig, move.dest);
      }, 600);
    });
  },
  showCheckmate: function (shogi) {
    console.log("SHOW CHECKMATE?", shogi)
  },
  setShapes: function (shapes) {
    cg.setShapes(shapes);
  },
  resetShapes: function () {
    cg.setShapes([]);
  },
  select: cg.selectSquare
};
