
var Shogi = require("shogiutil/vendor/Shogi.js").Shogi;
var util = require('./util');

module.exports = function (fen, appleKeys) {

  var shogi = Shogi.Init(fen);

  // adds enemy pawns on apples, for collisions
  if (appleKeys) {
    var color = shogi.turn === 'white' ? 'b' : 'w';
    var fen = shogi.fen;
    appleKeys.forEach(function (key) {
      fen = shogi.place(fen, 'pawn', color, key)
    });
    updateShogi(fen);
  }

  function updateShogi(fen) {
    shogi = Shogi.Init(fen);
  }

  function getColor() {
    return shogi.player == "white" ? "white" : "black";
  }

  function setColor(c) {
    var turn = c === 'white' ? 'w' : 'b';
    var newFen = util.setFenTurn(shogi.fen, turn);
    updateShogi(newFen);
  }

  function filterPieces(c) {
    var allPos = [];
    for (var i in shogi.pieceMap) {
      if (shogi.pieceMap[i].startsWith(c)) {
        allPos.push(i)
      }
    }
  }

  function findKing(c) {
    let king;
    if (color === 'white')
      king = 'white-king';
    else king = 'black-king';
    for (var i in shogi.pieceMap) {
      if (shogi.pieceMap[i] === king) {
        return i;
      }
    }
  }

  var findCaptures = function () {
    var allCaptures = [];
    const pieces = filterPieces(getColor());
    for (var i in shogi.dests) {
      for (var j in shogi.dests[i]) {
        if (pieces.includes(shogi.dests[i][j]))
          allCaptures.push({ orig: i, dest: shogi.dests[i][j] });
      }
    }
    return allCaptures;
  }

  return {
    dests: function (opts) {
      opts = opts || {};
      if (opts.illegal) return Shogi.getUnsafeDests(shogi.fen)
      return shogi.dests;
    },
    color: function (c) {
      if (c) setColor(c);
      else return getColor();
    },
    fen: shogi.fen,
    move: function (orig, dest, prom) {
      const s = Shogi.move(shogi.fen, orig, dest, prom ? prom : "");
      updateShogi(s.fen);
      return { orig, dest, prom };
    },
    occupation: function () {
      return shogi.pieceMap;
    },
    kingKey: function (color) {
      return findKing(color);
    },
    findCapture: function () {
      return findCaptures()[0];
    },
    findUnprotectedCapture: function () {
      return findCaptures().find(function (capture) {
        var clone = Shogi.move(shogi.fen, capture.orig, capture.dest);
        for (var i in clone) {
          for (var j in clone[i]) {
            if (clone[i][j] === capture.dest) {
              return true;
            }
          }
        }
        return false;
      });
    },
    checks: function () {
      return null;
    },
    playRandomMove: function () {
      const orig = Object.keys(shogi.dests)[Math.floor(Math.random() * Object.keys(shogi.dests).length)]
      const moves = shogi.dests[orig];
      const dest = moves[Math.floor(Math.random() * moves.length)];
      updateShogi(Shogi.move(shogi.fen, orig, dest))
      return {
        orig: orig,
        dest: dest
      };
    }
  };
};
