package org.lichess.compression.game;

public enum Role {
    PAWN(0, ""),
    KNIGHT(1, "N"),
    BISHOP(2, "B"),
    ROOK(3, "R"),
    KING(4, "K"),
    GOLD(5, "G"),
    SILVER(6, "S"),
    LANCE(7, "L"),
    TOKIN(8, "T"),
    PROMOTEDLANCE(9, "U"),
    PROMOTEDKNIGHT(10, "M"),
    PROMOTEDSILVER(11, "A"),
    HORSE(12, "H"),
    DRAGON(13, "D");

    public final int index;
    public final String symbol;

    Role(int index, String symbol) {
        this.index = index;
        this.symbol = symbol;
    }
}
